# 🧾 Expense Tracker (with Login System)

A command-line based **Expense Tracker** written in Python. This version allows multiple users to sign up and log in securely. Each user has their own separate CSV file where their expenses are recorded.

---

## 🔐 Features

- ✅ User **Signup** and **Login** system (stores credentials in `users.csv`)
- ✅ Add, View, and Delete expenses
- ✅ **Filter** expenses by Category or Date
- ✅ Generate **Monthly Expense Reports**
- ✅ Each user has their own data file (`username_expenses.csv`)
- ✅ All data stored in the same folder

---

## 🏁 How It Works

1. Run the program:  
   
   python expense_tracker.py


2. Choose:

   * `Login` if you already have an account
   * `Sign Up` to create a new account

3. After login, manage your expenses using the menu.

---

## 📦 File Structure


├── expense_tracker.py         # Main program
├── users.csv                  # Stores usernames & passwords
├── username_expenses.csv      # One file per user (e.g., ahmad_expenses.csv)
├── README.md                  # This file


---

## 📊 Sample Expense Format (CSV)

Each user's file contains:


Date,Category,Amount,Description
12-05-2025,Food,500,Lunch at canteen
13-05-2025,Transport,100,Bus fare


---

## ✅ Requirements

* Python 3.x
* No third-party libraries required (uses built-in modules only)

---

## 💡 Future Improvements (Optional)

* Add a GUI interface using Tkinter or PyQt
* Add password hashing for more secure login
* Export reports to PDF or Excel
* Add budgeting and reminders

---

## 👨‍💻 Author

Developed by [Ahmad2627](https://github.com/Ahmad2627)

---

## 📜 License

This project is open-source and free to use.

---

