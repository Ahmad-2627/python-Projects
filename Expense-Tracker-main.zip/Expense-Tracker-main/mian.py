import csv
import os
# import getpass
from collections import defaultdict

users_file = "users.csv"
file_name = ""  # Will be set based on logged-in user


# ====================== LOGIN SYSTEM ======================

def signup():
    print("\n--- Sign Up ---")
    username = input("Choose a username: ").strip()
    # password = getpass.getpass("Choose a password: ").strip()
    password = input("Enter your password: ")

    if os.path.exists(users_file):
        with open(users_file, 'r') as file:
            users = [row[0] for row in csv.reader(file)]
            if username in users:
                print("Username already exists. Try another.\n")
                return None

    with open(users_file, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([username, password])
    print("Account created successfully!\n")
    return username


def login():
    print("\n--- Login ---")
    username = input("Enter username: ").strip()
    # password = getpass.getpass("Enter password: ").strip()
    password = input("Enter your password: ")


    if os.path.exists(users_file):
        with open(users_file, 'r') as file:
            for row in csv.reader(file):
                if row[0] == username and row[1] == password:
                    print("Login successful!\n")
                    return username
    print("Invalid credentials. Try again.\n")
    return None


# ====================== EXPENSE TRACKER ======================

def add_expense():
    date = input("Enter date (DD-MM-YYYY): ")
    category = input("Enter category: ")
    amount = input("Enter amount: ")
    description = input("Enter description: ")

    with open(file_name, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([date, category, amount, description])
    print("Expense added successfully.\n")


def view_expenses(expenses=None):
    if not os.path.exists(file_name):
        print("No expenses found.\n")
        return

    if expenses is None:
        with open(file_name, 'r') as file:
            expenses = list(csv.reader(file))

    if not expenses:
        print("No expenses to display.\n")
        return

    total = 0
    print("\nYour Expenses:\n")
    print("No | Date       | Category     | Amount | Description")
    print("---------------------------------------------------------")
    for i, row in enumerate(expenses, start=1):
        print(f"{i:<2} | {row[0]:<10} | {row[1]:<12} | Rs.{row[2]:<6} | {row[3]}")
        total += float(row[2])
    print("---------------------------------------------------------")
    print(f"Total Spent: Rs.{total}\n")


def delete_expense():
    if not os.path.exists(file_name):
        print("No expenses to delete.\n")
        return

    with open(file_name, 'r') as file:
        rows = list(csv.reader(file))

    view_expenses(rows)

    try:
        num = int(input("Enter the expense number to delete: ")) - 1
        if 0 <= num < len(rows):
            deleted = rows.pop(num)
            with open(file_name, 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerows(rows)
            print(f"Deleted: {deleted}\n")
        else:
            print("Invalid number.\n")
    except ValueError:
        print("Please enter a valid number.\n")


def filter_by_category():
    if not os.path.exists(file_name):
        print("No data to filter.\n")
        return

    category = input("Enter category to filter: ").strip().lower()
    with open(file_name, 'r') as file:
        expenses = [row for row in csv.reader(file) if row[1].lower() == category]

    view_expenses(expenses)


def filter_by_date():
    if not os.path.exists(file_name):
        print("No data to filter.\n")
        return

    date = input("Enter date to filter (DD-MM-YYYY): ").strip()
    with open(file_name, 'r') as file:
        expenses = [row for row in csv.reader(file) if row[0] == date]

    view_expenses(expenses)


def monthly_report():
    if not os.path.exists(file_name):
        print("No data to analyze.\n")
        return

    monthly_totals = defaultdict(float)

    with open(file_name, 'r') as file:
        for row in csv.reader(file):
            if len(row) < 3:
                continue
            date = row[0]
            amount = float(row[2])
            month = date[3:10]  # MM-YYYY
            monthly_totals[month] += amount

    if not monthly_totals:
        print("No data found.\n")
        return

    print("\n--- Monthly Report ---")
    for month, total in monthly_totals.items():
        print(f"{month}: Rs.{total}")
    print()


# ====================== MAIN MENU ======================

def main():
    global file_name
    print("=== Welcome to Expense Tracker ===")

    username = None
    while not username:
        print("1. Login")
        print("2. Sign Up")
        choice = input("Choose an option: ")
        if choice == '1':
            username = login()
        elif choice == '2':
            username = signup()
        else:
            print("Invalid option.\n")

    file_name = f"{username}_expenses.csv"

    while True:
        print("=== Expense Tracker ===")
        print("1. Add Expense")
        print("2. View All Expenses")
        print("3. Delete Expense")
        print("4. Filter by Category")
        print("5. Filter by Date")
        print("6. Monthly Report")
        print("7. Exit")

        choice = input("Choose an option: ")

        if choice == '1':
            add_expense()
        elif choice == '2':
            view_expenses()
        elif choice == '3':
            delete_expense()
        elif choice == '4':
            filter_by_category()
        elif choice == '5':
            filter_by_date()
        elif choice == '6':
            monthly_report()
        elif choice == '7':
            print("Goodbye!")
            break
        else:
            print("Invalid option. Try again.\n")


if __name__ == "__main__":
    main()
